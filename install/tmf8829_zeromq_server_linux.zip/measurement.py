# *****************************************************************************
# * Copyright by ams OSRAM AG                                                 *
# * All rights are reserved.                                                  *
# *                                                                           *
# *FOR FULL LICENSE TEXT SEE LICENSES-MIT.TXT                                 *
# *****************************************************************************
import time

from typing import List
from tmf8829_application_defines import tmf8829FrameHeader
from tmf8829_application_common import *
from utilities.tmf8829_application_printer import Tmf8829ApplicationPrinter

############################################################

DRIVER_PATH    = "/sys/class/i2c-adapter/i2c-0/0-0041/"
START_MEAS     = "tmf8829_app/start_measurement"
CONFIG_MODE    = "tmf8829_app/config_mode"
RESULT_FORMAT  = "tmf8829_app/result_format"
FP_MODE        = "tmf8829_app/fp_mode"
HISTOGRAMS     = "tmf8829_app/histograms"
PERIOD         = "tmf8829_app/period"
READ_DATA      = "tmf8829_app/app_tof_output"
READ_DATA_MISC = "/dev/tof_tmf8829"

DRIVER_HEADER_SIZE = 4

############################################################
## USER SETTINGS                                          ##
############################################################

NUMBER_OF_FRAMES      = 20
config_mode           = 0x43
user_fpmode           = Tmf8829AppCommon.FP_MODE_16x16 
histograms            = 0
period                = 33

PRINT_WHOLE_FRAME = False # Note more printing could end in lost frames if period is to low
OUTPUT_FILE_NAME = "demofile.txt"
############################################################
PAGE_SIZE = 4096
def read_from_misc_device(device_path):
    try:
        with open(device_path, 'rb') as device_file:
            data = device_file.read(PAGE_SIZE * 64)
            return data
    except IOError as e:
        print(f"Error reading from device: {e}")
        return None
############################################################

if __name__ == "__main__":

    result = read_from_misc_device(READ_DATA_MISC)
    print("Cleared old data", len(result)  )

    # -----------------------------------------------------
    # make sure that no measurement is running 
    # -----------------------------------------------------

    f1 = open(DRIVER_PATH+START_MEAS, "w")
    f1.write("0")
    f1.close()
    time.sleep(0.02)

    # -----------------------------------------------------
    # set config mode
    # -----------------------------------------------------

    f1 = open(DRIVER_PATH+CONFIG_MODE, "w")
    f1.write(f"{hex(config_mode)}\n")
    f1.close()
    time.sleep(0.02)

    # -----------------------------------------------------
    # histograms
    # -----------------------------------------------------

    f1 = open(DRIVER_PATH+HISTOGRAMS, "w")
    f1.write(f"{histograms}\n")
    f1.close()
    time.sleep(0.02)

    # -----------------------------------------------------
    # period
    # -----------------------------------------------------

    f1 = open(DRIVER_PATH+PERIOD, "w")
    f1.write(f"{period}\n")
    f1.close()
    time.sleep(0.02)

    # -----------------------------------------------------
    # read the focal plane mode and the result layout
    # calculate the frame result size
    # -----------------------------------------------------

    f1 = open(DRIVER_PATH+FP_MODE, "r")
    result = f1.read(1)
    fpmode = int(list(result)[0])
    f1.close()

    f1 = open(DRIVER_PATH+RESULT_FORMAT, "r")
    result = f1.read(1)
    res_format = int(list(result)[0])
    f1.close()
    size_of_result_frame = DRIVER_HEADER_SIZE+ Tmf8829AppCommon.PRE_HEADER_SIZE+ TMF8829_FRAME_HEADER_SIZE \
                         + Tmf8829AppCommon.resultFrameDataSize(fpmode , res_format) + TMF8829_FRAME_FOOTER_SIZE
    print(size_of_result_frame)

    # -----------------------------------------------------
    # start the measurement
    # -----------------------------------------------------

    f1 = open(DRIVER_PATH+START_MEAS, "w")
    f1.write("1")
    f1.close()

    # -----------------------------------------------------
    # read out the frames
    # -----------------------------------------------------
    captured_measurement = 0
    TIMEOUT = 1
    max_time = TIMEOUT
    POLLTIME = 0.01
    LEN_DRIVER_HEADER = 8

    while captured_measurement < NUMBER_OF_FRAMES:

        result = read_from_misc_device(READ_DATA_MISC)

        result_length = len(result)
        if result_length == 0:
            time.sleep(POLLTIME)
            max_time = max_time - POLLTIME
            if max_time <= 0:
                print("Timeout")
                break
        else:
            max_time = TIMEOUT
            print("Read Data ",  result_length)
            # --- sepperate the frames --- #
            data = list(result)
            
            while (len(data) >= LEN_DRIVER_HEADER):
                captured_measurement = captured_measurement + 1
                if (captured_measurement > NUMBER_OF_FRAMES):
                    break

                driver_header = data[0:LEN_DRIVER_HEADER]
                payload = driver_header[6] + driver_header[7] * 256
                frame = data[LEN_DRIVER_HEADER:LEN_DRIVER_HEADER+payload]
                data = data[LEN_DRIVER_HEADER+payload:]
                
                print("Header: ", driver_header, " Payload:", payload )

                # Note if print_result_details are printed the distance is in 0.25 mm
                Tmf8829ApplicationPrinter.printFrame(frame, print_whole_frame=PRINT_WHOLE_FRAME, print_result_details=False) 
                f = open(OUTPUT_FILE_NAME, "a")
                f.write("frame")
                f.write(f"{frame}\n")
                f.close()
                
    # -----------------------------------------------------
    # stop the measurement
    # -----------------------------------------------------
    time.sleep(0.1)
    f1 = open(DRIVER_PATH+START_MEAS, "w")
    f1.write("0")
    f1.close()
